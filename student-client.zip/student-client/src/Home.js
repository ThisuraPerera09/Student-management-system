import React from "react";

const Home = () => {
	return (
		<div>
			<h2>Welcome to the home page</h2>
		</div>
	);
};

export default Home;
